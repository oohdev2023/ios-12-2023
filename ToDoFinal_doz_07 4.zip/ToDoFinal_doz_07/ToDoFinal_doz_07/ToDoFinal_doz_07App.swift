//
//  ToDoFinal_doz_07App.swift
//  ToDoFinal_doz_07
//
//  Created by Student on 18.12.23.
//

import SwiftUI

@main
struct ToDoFinal_doz_07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
