//
//  FormData.swift
//  ToDoFinal_doz_07
//
//  Created by Student on 18.12.23.
//

import Foundation

struct FormData{
    
    let name:String
    let description:String
    let selectedCat:Int
    let finishDate:Date
    
}
