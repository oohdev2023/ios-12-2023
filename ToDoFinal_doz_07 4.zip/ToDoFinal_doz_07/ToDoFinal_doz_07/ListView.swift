//
//  ListView.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct ListView: View {
    
    var allTodos:[ToDo]!
    
    @EnvironmentObject var dc:DataController
    
    
    
    let defaults = UserDefaults.standard
    @State private var isShowingPopover = false
    var body: some View {
       
        
        
        Menu("sort") {
                   Button("sort by date >", action: dc.sortDateDes)
                   Button("sort by date <", action: dc.sortDateAsc)
                   Button("abort", action: cancel)
               }
        
        
        Menu("filter") {
                   Button("sort by date >", action: dc.sortDateDes)
                   Button("sort by date <", action: dc.sortDateAsc)
                   Button("abort", action: cancel)
               }
        
        
       /* List(allTodos, id: \.id){ todo in
            ListItem(todo: todo)
        }*/
        
        List{
            ForEach(allTodos, id: \.id) { todo in //---- Ein List Item
                ListItem(todo: todo)
            }.onDelete(perform: delete)
        }
    }
    
    func cancel(){
        
    }
    
    func delete(at offsets: IndexSet) {
        //print(offsets.first)
        
        //print(self.allTodos[offsets.first!].id)
        //let idsToDelete = offsets.map { self.allTodos[$0].id }
        
        //print(idsToDelete)
        //dc.deletTodo(index: offsets.first!)
        dc.deletTodo(id: allTodos[offsets.first!].id)
    
    }}


struct ListItem:View {
    
    var todo:ToDo
    
    var body: some View {
        VStack(alignment: .leading){
            HStack{
                Rectangle().fill(Color.init(hex: todo.daysLeftColor)!).frame(width: 20,height: 30)
                Text("\(todo.name) / days left:\(todo.daysLeft)")
                Spacer()
                
            }
            Text(todo.categoryString)
            Text(getDateString(d:todo.finishDate))
        }
    }
    
    func getDateString(d:Date)->String{
        
        let formatter3 = DateFormatter()
        formatter3.dateFormat = "dd.MM.yyyy-HH:mm"
        return formatter3.string(from: d)
        
    }
    
    
}




