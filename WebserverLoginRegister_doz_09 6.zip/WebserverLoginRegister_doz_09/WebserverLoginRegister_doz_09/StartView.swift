//
//  StartView.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import SwiftUI

struct StartView: View {
    
    
    @EnvironmentObject var dc:DataController
    
    var body: some View {
        
        Button("logout") {
            dc.isLogin = false
        }
        
        AsyncImage(url: URL(string: "http://127.0.0.1/ios24/signinsignup/media/avatars/\(dc.userDataloged["avatar"] ?? "avatar")"))
        Text("Avatar:\(dc.userDataloged["avatar"] ?? "avatar")")
        Text("Hello,\(dc.userDataloged["username"] ?? "USER")")
        
        
        
        
        
    }
}

#Preview {
    StartView()
}
