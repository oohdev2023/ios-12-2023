//
//  ContentView.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var dc:DataController = DataController()
    
    
    
    @State var formData:[String:String] = ["u":"","p":""]

    var body: some View {
        VStack{
           /* 
            if(dc.isAlert){
               Text(dc.userDataErrorloged["txt"] ?? "")
            }
            */
            
            
            if(!dc.isLogin){
                if(dc.pageID == 0){
                    SignInView(pageID: $dc.pageID, formData: $formData.onChange(isLoginValid))
                    
                }
                
                if(dc.pageID == 1){
                    SignUpView(pageID: $dc.pageID).environmentObject(dc)
                }
            }else{
                StartView().environmentObject(dc)
            }
        }.alert(dc.userDataErrorloged["txt"] ?? "", isPresented: $dc.isAlert) {
            Button("OK", role: .cancel) { }
        }
        
        
        
    }
    
    func isLoginValid(value:[String:String]){
        dc.sendLoginDataPost(formData:value)
    }
}

#Preview {
    ContentView()
}

//1. In die ContentView muss ein AlertFenster oder Text in dem dann die Fehlermeldung angezeigt wird
//2. im DataController muss eine Variable gesetzt werden welche die Anzeige des Alerts oder des Textes auslöst
//3. Im DataController muss die Rückgabe des Servers komplet gespeichert werden, damit sie in der Ausgabe(Alertoder Text angezeigt wird)
