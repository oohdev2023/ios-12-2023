//
//  WebserverLoginRegister_doz_09App.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import SwiftUI

@main
struct WebserverLoginRegister_doz_09App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
