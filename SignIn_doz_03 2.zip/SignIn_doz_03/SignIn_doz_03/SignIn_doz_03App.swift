//
//  SignIn_doz_03App.swift
//  SignIn_doz_03
//
//  Created by Student on 05.12.23.
//

import SwiftUI

@main
struct SignIn_doz_03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
