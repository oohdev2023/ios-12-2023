//
//  ContentView.swift
//  SignIn_doz_03
//
//  Created by Student on 05.12.23.
//

import SwiftUI

struct ContentView: View {
    
    @State var currentIndex = 1
    @State var userTxt:String = ""
    @State var passtxt:String = ""
    
    
    var body: some View {
        VStack {
            
            //######################------------######################
            if(currentIndex == 0  ){
                Image("avatar")
                Text("Sign in").font(.title).fontWeight(.bold).foregroundColor(Color.green)
                Spacer()
                TextField("user",text:$userTxt).textFieldStyle(.roundedBorder).autocapitalization(.none)
                TextField("pass", text:$passtxt).textFieldStyle(.roundedBorder).autocapitalization(.none)
                
                Button("login"){
                    checklogin()
                }.font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(minWidth: 10,maxWidth: .infinity)
                    .background(.green)
                Spacer()
            }
            
            //######################------------######################
            
            if(currentIndex == 1 ){
                HStack{
                    Button{
                       currentIndex = 0
                    }label:{
                        Image(systemName: "arrowshape.turn.up.backward")
                    }
                    Spacer()
                }
                Text("Welcome \(userTxt) !").font(.largeTitle).fontWeight(.bold).padding(20)
                Spacer()
                
            }
            
            //######################------------######################
            
            if(currentIndex == 2 ){
                Text("Invalid")
                
            }
        }
        .padding()
    }
    
    
    func checklogin(){
        if(userTxt == "ich" && passtxt == "letmein"){
            currentIndex = 1
        }else{
            currentIndex = 2
        }
    }
    
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
