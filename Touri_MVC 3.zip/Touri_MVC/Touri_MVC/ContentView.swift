//
//  ContentView.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import SwiftUI

struct ContentView: View {
    
    //Erzeuge eine Instanz/Objekt der Class und fülle dadurch automatisch die Daten in die Liste
    var dc:DataController = DataController()
    
    var body: some View {
        VStack {
            NavigationStack{
            //Über die Instanzvariable kann jetzt immer auf die Daten(Liste) zugegriffen werden
            List{
                ForEach(dc.allData, id:\.id) { place in
                  
                    NavigationLink(destination: DetailView(place:place)){
                        HStack{
                            Image(place.img).resizable().frame(width: 50,height:50)
                            Text(place.title)
                        }
                    }
                    
                }
            }
//List(Array mit Objekten, Eigenschaft des Objektes im Array welche eindeutig ist)
/*Erzeugt pro Eintrag im Array ein Listelement und speichert
            für den Zeitraum der Erzeugung den Datensatz i place */
            
                List(dc.allData,id:\.id){ place in
                    //---- Ein List Item
                    NavigationLink(destination: DetailView(place:place)){
                        HStack{
                            Image(place.img).resizable().frame(width: 50,height:50)
                            Text(place.title)
                        }
                    }
                }
            }
        }
        .padding()
    }
}







#Preview {
    ContentView()
}
