//
//  Svars.swift
//  Touri_MVC
//
//  Created by Student on 13.12.23.
//

import Foundation


class Svars{
    
    
    static var userLat:Double = 52.51536466441821
    static var userLon:Double = 13.470773359521782
    
}
