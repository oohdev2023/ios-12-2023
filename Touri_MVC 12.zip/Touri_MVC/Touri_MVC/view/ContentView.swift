//
//  ContentView.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import SwiftUI

struct ContentView: View {
    
    //Erzeuge eine Instanz/Objekt der Class und fülle dadurch automatisch die Daten in die Liste
    @ObservedObject var dc:DataController = DataController()
    
    var body: some View {
        
            NavigationStack{
                VStack {
                 ListView(allData: dc.getAllData()).onAppear{
                     print("aktualisiere Daten im Array ")
                     dc.filterData()
                 }
               
                }.navigationBarTitle(Text("TOURIS FOREVER"),displayMode: .inline)
                    .toolbar {
                        
                            ToolbarItem(placement: .topBarTrailing) {
                                NavigationLink(destination: OptionView(),label:{ Image(systemName: "gear")})
                            }
                            ToolbarItem(placement: .bottomBar) {
                                NavigationLink(destination: ListView(allData: dc.getAllData()), label:{ Image(systemName: "list.bullet")})
                            }
                            ToolbarItem(placement: .bottomBar) {
                                NavigationLink(destination: MapView(allData: dc.getAllData()), label:{ Image(systemName: "map")})
                            }
                            ToolbarItem(placement: .bottomBar) {
                                NavigationLink(destination: GridView(allData: dc.getAllData()), label:{ Image(systemName: "square.grid.2x2")})
                            }
                        
                    }
                
           }
        .padding()
    }
}







#Preview {
    ContentView()
}
