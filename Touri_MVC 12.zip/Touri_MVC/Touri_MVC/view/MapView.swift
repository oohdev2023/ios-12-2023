//
//  MapView.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI
import MapKit

struct MapView: View {
    
    
    var allData:[Place]!
    
    var body: some View {
        
        VStack{
         
            Map {
            
                ForEach(allData, id: \.id) { place in
                    Marker(place.title, coordinate: CLLocationCoordinate2D(latitude: place.lat, longitude: place.lon))
                        .tint(.blue)
                }
                
                Marker("YOU", coordinate: CLLocationCoordinate2D(latitude: Svars.userLat, longitude: Svars.userLon))
                
                //Marker("Paris", coordinate: CLLocationCoordinate2D(latitude: 48.86077477282433, longitude: 2.2948499426949893))
                
                
           }
            
        }
        
    }

    
    
}

#Preview {
    MapView(allData: DataController().allDataFilter)
}
