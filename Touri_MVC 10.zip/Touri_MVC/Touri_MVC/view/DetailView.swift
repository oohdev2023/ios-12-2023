//
//  DetailView.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import SwiftUI

struct DetailView: View {
    
    var place:Place!
    
    var body: some View {
        Text(place.title)
        Image(place.img).resizable().frame(width: 200,height:150)
        Text(place.categorie)
        Text(String(place.lat))
        Text("\(place.lon)")
        Text("\(place.ranking)")
        StarsView(rating: CGFloat(place.ranking), maxRating: 5)
    }
}


