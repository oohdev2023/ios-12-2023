//
//  OptionVew.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct OptionView: View {
    
    @State var searchTxt:String = ""
    
    @State var toggleBool:[Bool] = [true,true]
    
    @State var sliderValue:Double = 3.0
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {
            Section(header: Text("search")) {
                TextField("search",text:$searchTxt)
            }
            
            Section(header: Text("categories")) {
                Toggle(isOn: $toggleBool[0]) {
                    Text("clubs:")
                }
               
                Toggle(isOn: $toggleBool[1]) {
                    Text("sights:")
                }
                
            }
            
            Section(header: Text("radius search")) {
                HStack {
                    Text("distance in km:")
                        
                    Text(String(sliderValue))
                   // TextField("",text: String($sliderValue))
                        
                }
                
                Slider(value: $sliderValue, in: 1...30, step: 0.5)
                    .padding(.horizontal, 10)
            }
            
        
            Section {
                HStack{
                    Spacer()
                    Button("save") {
                        //speicher die daten in einer interne ablage für jede app einzeln vorhanden
                        saveOption()
                        //schliesse diese View über den aufruf
                        presentationMode.wrappedValue.dismiss()
                    }
                    Spacer()
                    Button("cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                    Spacer()
                }
                
            }.onAppear{
                //Bei Anzeigen der OptionView lade alle Sucheinstellungen und zeige diese an
                loadOption()
            }
        }.navigationBarBackButtonHidden(true)
        
    }
    
    
    let defaults = UserDefaults.standard
    func saveOption(){
       
        defaults.set(searchTxt, forKey: "searchtxt")
        defaults.set(toggleBool, forKey: "categoriesBool")
        defaults.set(sliderValue, forKey: "distance")
    }
    
    func loadOption(){
      
            searchTxt  = defaults.string(forKey: "searchtxt") ?? ""
            
            toggleBool = (defaults.array(forKey: "categoriesBool") as? [Bool]) ?? [true,true]
            sliderValue  = defaults.double(forKey: "distance")
        
    }
    
    
}
