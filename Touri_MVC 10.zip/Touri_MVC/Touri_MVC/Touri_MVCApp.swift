//
//  Touri_MVCApp.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import SwiftUI

@main
struct Touri_MVCApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
