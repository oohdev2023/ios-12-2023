//
//  ContentView.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ContentViewTap: View {
    
    
    //===--- Definitionsbereich für Variabeln etc. ----===
    //Diese variable wird zum Wechseln der Ansichten benutzt
    @State var currentIndex:Int = -1
    //catIndex            0       1     2
    var aCat:[String] = ["club","food","sight"]
    var aCatTxt:[String] = ["clubing","fooding","sights"]
    
    //====-View Bereich für UI-Dahrstellung -=========================
    var body: some View {
        VStack {
            
            //Wenn die variable auf 1 gesetzt ist wird die Hauptseite angeszeigt
            if (currentIndex == -1){
                Text("Touri info").modifier(MyTitle())
                
                //ImageRound ist eine ausgelagertes Template in der Datei(ImageRound) und
                //erwartet 2 Parameter 1. img für das Bild und 2. für den Text
             
                ImageRoundTap(catIndex: 0,img:aCat[0],txt:aCatTxt[0], currentIndex: $currentIndex).padding()
                ImageRoundTap(catIndex: 1,img:aCat[1],txt: aCatTxt[1],currentIndex: $currentIndex).padding()
                ImageRoundTap(catIndex: 2,img:aCat[2],txt: aCatTxt[2],currentIndex: $currentIndex).padding()
            }
            
            
            //Bei allen anderen Werten wird die ListView(extra Struct) angezeigt
            if (currentIndex == 0 || currentIndex == 1 || currentIndex == 2 ){
                //Template aus der Datei ListView 
               ListView(currentIndex: $currentIndex, title: aCatTxt[currentIndex])
            }
            
            
        }
        .padding()
    }
    //=====-END VIEW-==
    
    //====-Funktionsbereich für Funktionen etc. --===
    
    
    
    //=====---=======
}
//=====-END Struct-==

#Preview {
    ContentViewTap()
}
