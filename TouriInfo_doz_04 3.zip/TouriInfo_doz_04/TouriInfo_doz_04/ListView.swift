//
//  ListView.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ListView: View {
    
    //Muss beim Benutzen dieser Struktur in passende Variable aufgelöst bzw. mit passender Variable verknüpft werden
    @Binding var currentIndex:Int
    //Erzwungender Parameter (muss mitgeliefert werden, da kein Wert gesetzt ist)
    var title:String!
    
    
    var body: some View {
        VStack{
            HStack{
                Button("back"){
                    currentIndex = -1
                }
                Spacer()
            }
            Spacer()
            Text(title).mytitle()
            
            Spacer()
        }
    }
}


