//
//  OptionVew.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct OptionView: View {
    
    @State var searchTxt:String = ""
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {

                   List {
                       Section(header: Text("Search")) {
                           TextField("search",text:$searchTxt)
                       }

                       /*Section(header: Text("Sleep tracking settings")) {
                           Toggle(isOn: $isSleepTrackingEnabled) {
                               Text("Sleep tracking:")
                           }*/

                       }
                       
                       Section {
                           Button("save") {
                               //speicher die daten in einer interne ablage für jede app einzeln vorhanden
                               let defaults = UserDefaults.standard
                               defaults.set(searchTxt, forKey: "searchtxt")
                               //schliesse diese View über den aufruf
                               presentationMode.wrappedValue.dismiss()
                           }
                           Button("cancel") {
                               presentationMode.wrappedValue.dismiss()
                           }
                       }.onAppear{
                           //Bei Anzeigen der OptionView lade alle Sucheinstellungen und zeige diese an
                           let defaults = UserDefaults.standard
                           searchTxt = defaults.string(forKey: "searchtxt")!
                       }
    }
   
}


