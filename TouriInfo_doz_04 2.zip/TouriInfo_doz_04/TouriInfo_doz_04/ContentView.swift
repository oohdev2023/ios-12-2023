//
//  ContentView.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ContentView: View {
    
    @State var currentIndex:Int = -1
    
    var aCat:[String] = ["club","food","sight"]
    
    var body: some View {
        VStack {
            
            
            if (currentIndex == -1){
                Text("Touri info").modifier(MyTitle())
                
                
                ImageRound(img:"club",txt:"club").padding().onTapGesture(count: 1) {
                    currentIndex = 0
                }
                ImageRound(img:"food",txt: "food").padding().onTapGesture(count: 1) {
                    currentIndex = 1
                }
                ImageRound(img:"sight",txt: "sight").padding().onTapGesture(count: 1) {
                    currentIndex = 2
                }
            }
            
            
            
            if (currentIndex == 0 || currentIndex == 1 || currentIndex == 2 ){
               ListView(currentIndex: $currentIndex, title: aCat[currentIndex])
            }
            
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
