//
//  modifier.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import Foundation
import SwiftUI

struct MyTitle: ViewModifier {
    
    func body(content: Content) -> some View {
        content.font(.largeTitle).fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            .textCase(.uppercase)
        
    }
    
}


extension Text {
    func mytitle() -> some View {
        modifier(MyTitle())
    }
    
}
