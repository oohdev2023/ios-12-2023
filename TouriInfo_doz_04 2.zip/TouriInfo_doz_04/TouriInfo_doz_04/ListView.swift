//
//  ListView.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ListView: View {
    
    @Binding var currentIndex:Int
    var title:String!
    
    
    var body: some View {
        VStack{
            HStack{
                Button("back"){
                    currentIndex = -1
                }
                Spacer()
            }
            Spacer()
            Text(title).mytitle()
            
            Spacer()
        }
    }
}


