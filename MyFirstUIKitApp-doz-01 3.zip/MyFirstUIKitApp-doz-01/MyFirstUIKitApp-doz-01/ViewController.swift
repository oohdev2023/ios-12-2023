//
//  ViewController.swift
//  MyFirstUIKitApp-doz-01
//
//  Created by Student on 04.12.23.
//

import UIKit

class ViewController: UIViewController {

    var btn:UILabel = UILabel()
    @IBOutlet var btn2:UILabel!
    
    @IBOutlet var outPutLable: UILabel!
    @IBOutlet var txtField: UITextField!
    
    @IBAction func btnEvent(_ sender: UIButton) {
        outPutLable.text = txtField.text
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //UI / GFX ist geladen mache was
        outPutLable.text = ""
    }


}

