//
//  TouriInfo_doz_04App.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import SwiftUI

@main
struct TouriInfo_doz_04App: App {
    var body: some Scene {
        WindowGroup {
            ContentViewTap()
        }
    }
}
