//
//  ContentView.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ContentViewTapFor: View {
    
    
    //===--- Definitionsbereich für Variabeln etc. ----===
    //Diese variable wird zum Wechseln der Ansichten benutzt
    @State var currentIndex:Int = -1
    //catIndex            0       1     2
    var aCat:[String] = ["club","food","sight"]
    var aCatTxt:[String] = ["clubing","fooding","sights"]
    
    //====-View Bereich für UI-Dahrstellung -=========================
    var body: some View {
        VStack {
            
            //Wenn die variable auf 1 gesetzt ist wird die Hauptseite angeszeigt
            if (currentIndex == -1){
                Text("Touri info").modifier(MyTitle())
                
                //Für jeden Eintrag im Array aCat erzeuge ein ImageRoundTap-Objekt und gebe diesem die gewünschten Parameter, besonders den catIndex(0,1,2) mit sodas beim klicken die richtigen daten angezeigt werden können
                //for(i=0;i<3,i++){}
                // range: 0 ... 10
                //ForEach( (0...10)  , id: \.self) {
                 //   Text("Text\($0)")
                //}
                
                ForEach( (0 ..< aCat.count)  , id: \.self) {
                    //ImageRoundTap ist ein ausgelagertes Template in der Datei(ImageRoundTap) und
                    //erwartet 3 Parameter 1. img für das Bild und 2. für den Text und einen 3. für den Index(catIndex) zu welchen der Eintrag gehört
                    //Weiterhin ist eine BindingVariable zu verknüpfen die nach klicken auf das Bild den currentIndex in der ContentView dem richtigen Index des jeweiligen ImagRoundTap-Objektes setzt (0,1,2 ..)
                    ImageRoundTap(catIndex: $0,img:aCat[$0],txt:aCatTxt[$0], currentIndex: $currentIndex).padding()
                    
                }
            }
            
            
            //Bei allen anderen Werten wird die ListView(extra Struct) angezeigt
            if (currentIndex == 0 || currentIndex == 1 || currentIndex == 2 ){
                //Template aus der Datei ListView 
               ListView(currentIndex: $currentIndex, title: aCatTxt[currentIndex])
            }
            
            
        }
        .padding()
    }
    //=====-END VIEW-==
    
    //====-Funktionsbereich für Funktionen etc. --===
    
    
    
    //=====---=======
}
//=====-END Struct-==

#Preview {
    ContentViewTapFor()
}
