//
//  SwiftUIView.swift
//  TouriInfo_doz_04
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ImageRound: View {
    //Erzwungender Parameter für das Bild (muss mitgeliefert werden, da kein Wert gesetzt ist und kein Binding)
    var img:String!
    //Erzwungender Parameter für den Text (muss mitgeliefert werden, da kein Wert gesetzt ist und kein Binding)
    var txt:String!
    
    var body: some View {
        //Z-Ebene ... Objekte liegen mittig ausgerichte übereinander
        ZStack{
            
            Image(img).resizable()
                .frame(width:250,height:180)
                .opacity(0.7)
                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                .overlay(Circle()
                .stroke( Color.gray,lineWidth:2))
                .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            
            Text(txt).font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .foregroundColor(.white)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .textCase(.uppercase)
                .padding(.top, 100)
        }
    }
}

#Preview {
    ImageRound(img: "club",txt: "club")
}
