//
//  ImagePickerMapCoreData_doz_08App.swift
//  ImagePickerMapCoreData_doz_08
//
//  Created by Student on 19.12.23.
//

import SwiftUI

@main
struct ImagePickerMapCoreData_doz_08App: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
