//
//  ContentView.swift
//  ImagePickerMapCoreData_doz_08
//
//  Created by Student on 19.12.23.
//

import SwiftUI
import CoreData

struct ContentView: View {
    //Objekt(MangedObjectContext)Schnittstelle zum DB
    @Environment(\.managedObjectContext) private var viewContext

    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Place.id, ascending: true)],
        animation: .default)
    private var items: FetchedResults<Place>

    var body: some View {
        NavigationView {
            VStack{
                Text("HUHU").onAppear{
                    
                    addItem(title: "Place A", txt: "Toll hier ....", img: Data())
                    addItem(title: "Place B", txt: "Noch besser hier ....", img: Data())
                    print( getDocumentsDirectory())
                }
                List {
                    ForEach(items) { item in
                        NavigationLink {
                            VStack{
                                Text(item.title ?? "")
                                Text(item.txt ?? "")
                                Text(String(item.ranking))
                            }
                        } label: {
                            Text(item.title!)
                        }
                    }
                    .onDelete(perform: deleteItems)
                }
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        EditButton()
                    }
                    ToolbarItem {
                        
                    }
                }
            }
        }
    }
    
    //=============================--=======================================================
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    //==============-CORE DATE CONNECT METHODS-==================================================
    private func addItem(title:String,txt:String,img:Data) {
        withAnimation {
            //Objekt ohne Bezug zum CoreDataFramework ausser Datestruktur
            /*let p:Place =  Place()
                p.id = UUID()
            //Objekt mit CoreDate verbunden nzw. werden diese Objekte zum MangedObjectContext hinzugefügt und warten dort auf ....
            let newPlace1 = Place(context: viewContext)
            let newPlace2 = Place(context: viewContext)
            let newPlace3 = Place(context: viewContext)*/
            
            let p:Place = Place(context: viewContext)
                p.id    = UUID()
                p.title = title
                p.txt   = txt
                p.lat = 53.12333
                p.lon = 13.8888
                p.ranking = 3
            

            saveToCD()
        }
    }
   //-----------
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)

            saveToCD()
        }
    }
    //-----------
    private func saveToCD(){
        do {
            try viewContext.save()
        } catch {
            // Replace this implementation with code to handle the error appropriately.
            // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
    //-----------
}


#Preview {
    ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
}
