//
//  InvalidView.swift
//  SignIn_doz_03
//
//  Created by Student on 06.12.23.
//

import SwiftUI

struct ListView: View {
    
    var user:String = "john"
    @Binding var currentIndex:Int
    
    var body: some View {
        HStack{
            Button{
               currentIndex = 0
              
            }label:{
                Image(systemName: "arrowshape.turn.up.backward")
            }
            Spacer()
        }
        Text("Welcome \(user) !").font(.largeTitle).fontWeight(.bold).padding(20)
        Spacer()
    }
}




struct MyData{
    
    var var1:String = ""
    var var2:Int    = 0
    
}
