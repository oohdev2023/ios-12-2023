//
//  InvalidView.swift
//  SignIn_doz_03
//
//  Created by Student on 06.12.23.
//

import SwiftUI

struct SignInView: View {
    
   
    @State var passTxt:String = ""
    
    @Binding var userTxt:String
    @Binding var errorCount:Int
    @Binding var currentIndex:Int
    
    var body: some View {
        Image("avatar")
        Text("Sign in").font(.title).fontWeight(.bold).foregroundColor(Color.green)
        Spacer()
        
        if(errorCount < 3  ){
        
            TextField("user",text:$userTxt).textFieldStyle(.roundedBorder).autocapitalization(.none)
            TextField("pass", text:$passTxt).textFieldStyle(.roundedBorder).autocapitalization(.none)

            Button("login"){
                checklogin()
            }.font(.headline)
                .foregroundColor(.white)
                .padding()
                .frame(minWidth: 10,maxWidth: .infinity)
                .background(.green)
        
        }else{
          Button("setze die Fehlerversuche zurück"){
               errorCount = 0
            }
        }
        
            
        Spacer()
    }
    
    func checklogin(){
        if(userTxt == "ich" && passTxt == "letmein"){
            currentIndex = 1
        }else{
            errorCount += 1
            currentIndex = 2
        }
    }
    
}


