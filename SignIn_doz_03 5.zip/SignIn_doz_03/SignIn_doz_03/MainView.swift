//
//  ContentView.swift
//  SignIn_doz_03
//
//  Created by Student on 05.12.23.
//

import SwiftUI

struct MainView: View {
    
    @State var currentIndex = 0
    @State var userTxt:String = ""
    @State var errorCount:Int = 0
    
    
    var body: some View {
        VStack {
            
            //######################------LOGINSCREEN------######################
            if(currentIndex == 0  ){
              SignInView(userTxt: $userTxt, errorCount: $errorCount, currentIndex: $currentIndex)
            }
            
            //######################-----VALID LOGIN / STARTSCREEN APP-------######################
            
            if(currentIndex == 1 ){
               
                ListView(user: userTxt,currentIndex: $currentIndex)
            }
            
            //######################------INVALID LOGIN SCREEN------######################
            
            if(currentIndex == 2 ){
                InvalidView(errorCount:errorCount,currentIndex: $currentIndex)
            }
        }
        .padding()
    }
    
    
   
    
    
    
}

#Preview {
        MainView()
}

