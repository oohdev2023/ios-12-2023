//
//  ContentView.swift
//  ToDo_doz_06
//
//  Created by Student on 14.12.23.
//

import SwiftUI

struct ContentView: View {
    
    
    @ObservedObject var dc:DataController = DataController()
    
    @State var searchTxt:String = ""
    
    
    func callFilter(value:String){
        dc.filterDataSearchTxt(searchTxt: value)
        //dc.filterDataSearchTxt(searchTxt: searchTxt)
    }
    
    @State var formData:FormData = FormData(name: "", description: "", selectedCat: 0, finishDate: Date())
    
    var body: some View {
        Text(formData.name)
        NavigationStack{
            VStack {
                
                ListView(allTodos: dc.getAllTodos(), searchTxt:$searchTxt.onChange(callFilter))
                
                
            }.onAppear{
                //wird immer aufgerufen wenn diese Fenster (ListView) neu angezeigt wird
                dc.filterData()
                
            }.navigationBarTitle(Text("TOURIS FOREVER"),displayMode: .inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink(destination: OptionView(),label:{ Image(systemName: "gear")})
                    }
                    ToolbarItem(placement: .topBarLeading) {
                        NavigationLink(destination: AddView(allCategories:dc.getAllCategories(),formData: $formData.onChange(addToDo)),label:{ Image(systemName: "plus.circle")})
                    }
                    
                }   
        }.onAppear{
            //einmal beim start der app
            dc.loadCategories()
            dc.loadTodosFromFile()
        }
    }
    
    func addToDo(){
        //wird aufgerufen wenn im AddViewForm auf save gedrückt wird
        //Letzter Punkt : In DataController eine Funktion schreiben die die formData in Todo wandelt und zum array hinzufügt
    }
    
}

#Preview {
    ContentView()
}
