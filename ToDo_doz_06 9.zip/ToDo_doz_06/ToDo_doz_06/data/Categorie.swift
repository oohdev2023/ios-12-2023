//
//  Category.swift
//  ToDo_doz_06
//
//  Created by Student on 14.12.23.
//

import Foundation

struct Categorie{
    
    let id:Int
    let name:String
    let icon:String
    
    
}
