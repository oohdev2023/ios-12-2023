//
//  DataController.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import Foundation


class DataController:ObservableObject{
    
    //Leeres Array vom Typ [Place]
    //Hier kommen alle Datensätze als PlaceStruktur hinein
    private var allData:[Place] = [] //originale eingelesene Daten (nicht   gefiltert,nich sortiert nix...)
    @Published var allDataFilter:[Place] = []
    //Konstruktor
    /*Beim erzeugen eines Objektes/Instanz der Class(DataController)
    in der ContentView  var dc:DataController = DataController() werden durch den Aufruf der Funktion loadData() automatisch Daten in die leere Liste(allData) gefüllt*/
    init(){
       loadData()
    }
     //methode
    private func loadData(){
        //Erzeuge einen Datensatz aus der Struktur Place
        //Wenn die Vaiabeln in der Struktur let ohne Wert oder var sind , steht automatisch ein Konstruktor zum füllen der Werte in die Struktur zur Verfügung
       
        let p1 = Place(//id:0,
                       title: "Fernsehturm",
                       description: "Top View over Berlin",
                       img: "turm",
                       categorie: "sights",
                       lat: 13.5454545,
                       lon: 52.56456456,
                       ranking: 4, 
                       rankingStars: getRankingStarsFromRanking(ranking: 4))
        let p2 = Place(//id:1,
                       title: "Funkhaus",
                       description: "Relaxe & Music & Pizza",
                       img: "funkhaus",
                       categorie: "sights",
                       lat: 13.5454545,
                       lon: 52.56456456,
                       ranking: 5, 
                       rankingStars: getRankingStarsFromRanking(ranking:5))
        let p3 = Place(//id:2,
                       title: "Watergate",
                       description: "Tanz 24/7 on the Spree",
                       img: "watergate",
                       categorie: "clubs",
                       lat: 13.5454545,
                       lon: 52.56456456,
                       ranking: 3, 
                       rankingStars: getRankingStarsFromRanking(ranking:3))
        
        //Füge jeden erzeugten Datensatz in die Liste hinzu
        allData.append(p1)
        allData.append(p3)
        allData.append(p2)
        
        filterData()
    }
    
     func filterData(){
         allDataFilter = []
        print("filter data")
         var searchtxt:String = ""
    
        //gehe alle original Daten durch und prüfe mit searchstring
         let defaults = UserDefaults.standard
         if defaults.string(forKey: "searchtxt") != nil {
              searchtxt = defaults.string(forKey: "searchtxt")!
         }
         
         print(searchtxt)
         
         for item in allData{
             print(item.title)
               //Key exists
             if(item.title.contains(searchtxt)){
                 allDataFilter.append(item)
             }
         }
         
         print(allDataFilter)
    }
    
    
    //=======================-Zugriffs Methoden-==================================
    //gebe alle Daten zurück
    func getAllData()->[Place]{ return allDataFilter }
    // geb die Anzahl der Datensätz
    func getAllDataCount()->Int{ return allDataFilter.count }
   
    // geb ein Place in Abh. des ArrayIndexes zurück
    func getPlaceAt(index:Int)->Place{
        var tmpIndex:Int = index
        //wenn der mitgelieferte  index -1 .. ist dann setze diesen 0
        if(tmpIndex < 0){ tmpIndex = 0}
        //wenn der index größer  gleich der Anzahl der Elemente in dem Array ist
        //dann setze den Wert des index auf das letzte Element
        if(tmpIndex >= getAllDataCount()){ tmpIndex = getAllDataCount()-1}
        return allDataFilter[tmpIndex]
    }
    
    //=======================-Spezielle Projekt Methoden-==================================
    
    func getRankingStarsStringAt(index:Int)->String{
        var starsString:String = ""
        let ranking:Int = getPlaceAt(index: index).ranking
        
        for _ in 0 ... ranking{
            starsString.append("*")
        }
        
        return  starsString
    }
    
    
    func getRankingStarsFromRanking(ranking:Int)->String{
        var starsString:String = ""
        for _ in 0 ..< ranking{
            starsString.append("*")
        }
        
        return  starsString
    }
    
    
    func getRankingStarsIconAt(index:Int){
        
    }
    
    
}
