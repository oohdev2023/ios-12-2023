//
//  ListView.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct ListView: View {
    
     var allData:[Place]!
    
    var body: some View {
        List(allData,id:\.id){ place in
            //---- Ein List Item
            NavigationLink(destination: DetailView(place:place)){
                HStack{
                    Image(place.img).resizable().frame(width: 50,height:50)
                    Text(place.title)
                    Text(place.rankingStars)
                    StarsView(rating: CGFloat(place.ranking), maxRating: 5)
                }
            }
        }
    }
}

#Preview {
    ListView()
}
