//
//  OptionVew.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct OptionView: View {
    
    @State var searchTxt:String = ""
    
    var body: some View {

                   List {
                       Section(header: Text("Search")) {
                           TextField("search",text:$searchTxt)
                       }

                       /*Section(header: Text("Sleep tracking settings")) {
                           Toggle(isOn: $isSleepTrackingEnabled) {
                               Text("Sleep tracking:")
                           }*/

                       }
                       
                       Section {
                           Button("save") {
                               //speicher die daten in einer interne ablage für jede app einzeln vorhanden
                               let defaults = UserDefaults.standard
                               defaults.set(searchTxt, forKey: "searchtxt")
                               
                           }
                           Button("cancel") {
                               
                           }
                       }
                   }
   
}


