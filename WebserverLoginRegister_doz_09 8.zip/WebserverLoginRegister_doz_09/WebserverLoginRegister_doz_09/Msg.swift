//
//  Msg.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 10.01.24.
//

struct Msg:Codable {
    let uid, username, msgid, msg: String
    let send_date, img: String
}
