//
//  ContentView.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var dc:DataController = DataController()
    
    
    @State var pageID:Int = 0
    @State var formData:[String:String] = ["u":"","p":""]

    var body: some View {
        if(pageID == 0){
            SignInView(pageID: $pageID, formData: $formData.onChange(isLoginValid))
            
         }
        
        if(pageID == 1){
            SignUpView(pageID: $pageID).environmentObject(dc)
        }
    }
    
    func isLoginValid(value:[String:String]){
        dc.sendLoginData(formData:value)
    }
}

#Preview {
    ContentView()
}
