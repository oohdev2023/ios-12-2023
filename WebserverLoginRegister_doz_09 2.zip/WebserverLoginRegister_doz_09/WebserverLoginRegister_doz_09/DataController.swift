//
//  DataController.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import Foundation


class DataController:ObservableObject{
    
    
    func sendLoginData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")")
        
        let user:String   = formData["u"] ?? ""
        let pass:String   = formData["p"] ?? ""
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/signin.php?user=\(user)&pass=\(pass)"
        print(urlStr)
        //Wohin
        let url = URL(string: urlStr)!
        //let url = URL(string: "https://www.bild.de/")!
        //Was soll migesendet werden(POST)
        let request = URLRequest(url: url)
        //Wird gesendet
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
            //Beispiel Json:
              //ein object -> Dictionary -> beginnt mit {
            let dict = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [String:String]
            //unendlich viele objecte -> Array mit Dictionaries -> beginnt mit [ ->
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            print(dict["state"] ?? "")
        }
    
        
        task.resume()
        
        
    }
    
    func sendRegisterData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")/ \(formData["e"] ?? "")")
    }
    
    
}
