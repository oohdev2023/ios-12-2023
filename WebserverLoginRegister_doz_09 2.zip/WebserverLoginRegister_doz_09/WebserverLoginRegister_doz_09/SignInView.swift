

import SwiftUI

struct SignInView: View {
    
    //Für SeitenWechsel in der Main
    @Binding var pageID:Int
    @Binding var formData:[String:String]
    
    //-------------------------------------------------------------
    
    //Einmalig beim erzeugen der SignInView / schreibgeschützt
    var showSignInBtn:Bool = true
   //zwischenspeicher aller usereingaben andauernd
    @State var uservalue:String = ""
    @State var passwordvalue:String = ""
    //boolzum anzeigen und schliessen des alert fensters
    @State private var showingAlert = false
    
    var body: some View {
     
        
            Text("SIGNIN")
        
            Form {
                Section {
                    TextField("user", text: $uservalue)
                }

                Section {
                    TextField("password", text: $passwordvalue)
                }
                
                Button("send") {
                    checkForm(u: uservalue,p: passwordvalue)
                }
            }
            .padding().alert("Username or Password to short!", isPresented: $showingAlert) {
                Button("OK", role: .cancel) { }
            }
        if(showSignInBtn){
            Button("change to SignUp") {
                pageID = 1
            }
        }
        
    }
    
    
    
    func checkForm(u:String,p:String){
        if(u.count < 3  || p.count < 6){
            showingAlert = true
        }else{
            //packe Formdaten zusammen und sende sie an Main -> änder eine BindingVar zum Aktualisieren
            formData = ["u":u,"p":p]
        }
    }
    
    
}


