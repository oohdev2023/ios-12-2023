//
//  ForEachvsList_doz_05App.swift
//  ForEachvsList_doz_05
//
//  Created by Student on 07.12.23.
//

import SwiftUI

@main
struct ForEachvsList_doz_05App: App {
    var body: some Scene {
        WindowGroup {
            ContentViewFor()
        }
    }
}
