//
//  Msg.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 10.01.24.
//

struct Msg {
    let uid, username, msgid, msg: String
    let sendDate, img: String
}
