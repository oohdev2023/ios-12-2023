//
//  DataController.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import Foundation


class DataController:ObservableObject{
    
    @Published var pageID = 0
    
    //wird bei positivem Login auf true gesetzt und zeigt die StarView in der ContentView an
    @Published var isLogin:Bool = false
    //wird bei nagativem login auf true gesetzt und zeigt in der ContentView ein Alert an
    @Published var isAlert:Bool = false
     
    //antwort vom server wird hier gespeichert bei positiven login
    //leeres dictionary [:] , leeres arra []
    var userDataloged:[String:String] = [:]
    //antwort vom server wird hier gespeichert bei negativen login
    var userDataErrorloged:[String:String] = [:]
    
    var avatarUrl:String = "http://127.0.0.1/ios24/signinsignup/media/avatars/"
    
    
    
    func sendLoginDataPost(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")")
        
        let user:String   = formData["u"] ?? ""
        let pass:String   = formData["p"] ?? ""
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/signin.php"
        print(urlStr)
        //Wohin
        let url = URL(string: urlStr)!
        //let url = URL(string: "https://www.bild.de/")!
        //Was soll migesendet werden(POST)
        let postString = "user=\(user)&pass=\(pass)";
        
        var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.httpBody = postString.data(using: String.Encoding.utf8)
        
        //Wird gesendet
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
            //Beispiel Json:
              //ein object -> Dictionary -> beginnt mit {
            let dict = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [String:String]
            //unendlich viele objecte -> Array mit Dictionaries -> beginnt mit [ ->
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            print(dict["state"] ?? "")
            
            //gehe zurück zum MainThread
            DispatchQueue.main.async {
                self.checkServerOutputSignIn(dict:dict)
            }
            
        }
    
        
        task.resume()
        
        
    }
    
    
    
    
    func sendLoginData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")")
        
        let user:String   = formData["u"] ?? ""
        let pass:String   = formData["p"] ?? ""
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/signin.php?user=\(user)&pass=\(pass)"
        print(urlStr)
        //Wohin
        let url = URL(string: urlStr)!
        //let url = URL(string: "https://www.bild.de/")!
        //Was soll migesendet werden(POST)
        let request = URLRequest(url: url)
        //Wird gesendet
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
            //Beispiel Json:
              //ein object -> Dictionary -> beginnt mit {
            let dict = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [String:String]
            //unendlich viele objecte -> Array mit Dictionaries -> beginnt mit [ ->
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            print(dict["state"] ?? "")
            
            //gehe zurück zum MainThread
            DispatchQueue.main.async {
                self.checkServerOutputSignIn(dict:dict)
            }
            
        }
    
        
        task.resume()
        
        
    }
    
    func checkServerOutputSignIn(dict:[String:String]){
       //Wenn positive Antwort vom Server(state= 3)
            if(dict["state"] == "3"){
                userDataloged = dict
                //zeige startseite
                isLogin = true
                
            }else{
                //ansonsten gebe fehler aus
                //Versucht hier ein AlertFenster in der Main zu öffnen , mit der Ausgabe ... Ein Fehler ist aufgetreten
                userDataErrorloged = dict
                isAlert = true
            }
            
            
        }
    
    
    
    
    
    
    func sendRegisterDataPost(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")/ \(formData["e"] ?? "")")
        
        let user:String   = formData["u"] ?? ""
        let pass:String   = formData["p"] ?? ""
        let email:String   = formData["e"] ?? ""
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/signup.php"
        print(urlStr)
        //Wohin
        let url = URL(string: urlStr)!
        //let url = URL(string: "https://www.bild.de/")!
        //Was soll migesendet werden(POST)
        let postString = "user=\(user)&pass=\(pass)&email=\(email)";
        
        var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.httpBody = postString.data(using: String.Encoding.utf8)
        
        
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
            //Beispiel Json:
              //ein object -> Dictionary -> beginnt mit {
            let dict = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [String:String]
            //unendlich viele objecte -> Array mit Dictionaries -> beginnt mit [ ->
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            print(dict["state"] ?? "")
            
            DispatchQueue.main.async {
                self.checkServerOutputSignUp(dict:dict)
            }
            
            
        }
    
        
        task.resume()
        
        
        
    }
    
    
    
    
    func sendRegisterData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")/ \(formData["e"] ?? "")")
        
        let user:String   = formData["u"] ?? ""
        let pass:String   = formData["p"] ?? ""
        let email:String   = formData["e"] ?? ""
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/signup.php?user=\(user)&pass=\(pass)&email=\(email)"
        print(urlStr)
        //Wohin
        let url = URL(string: urlStr)!
        //let url = URL(string: "https://www.bild.de/")!
        //Was soll migesendet werden(POST)
        let request = URLRequest(url: url)
        //Wird gesendet
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
            //Beispiel Json:
              //ein object -> Dictionary -> beginnt mit {
            let dict = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [String:String]
            //unendlich viele objecte -> Array mit Dictionaries -> beginnt mit [ ->
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            print(dict["state"] ?? "")
        }
    
        
        task.resume()
        
        
        
    }
    
    
    func checkServerOutputSignUp(dict:[String:String]){
       //Wenn positive Antwort vom Server(state= 3)
        
                userDataErrorloged = dict
                isAlert = true
            
        //wenn register positiv verlaufen ...
                if(dict["state"] == "3"){
                    //gehe zum login
                    pageID = 0
                }
            
        }
    
    
    
    func getChatData(){
       
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/getAllMsg.php"
       
        let url = URL(string: urlStr)!
        let request = URLRequest(url: url)
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
          
            let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [Msg]
            //let candidate = try? JSONDecoder().decode([Msg.self],from: data)
            print(arr[0]["msg"] ?? "")
        }
        task.resume()
     }
    
}
