//
//  ErrorImage.swift
//  SignIn_doz_03
//
//  Created by Student on 06.12.23.
//

import SwiftUI

struct ErrorImage: View {
    
    var imgName:String = "exclamationmark.triangle"
    var size:Double    = 100
    
    var body: some View {
        Image(systemName: imgName)
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(.black, .red)
                            .font(.system(size: size))
    }
}


struct ErrorImage2: View {
    
    var imgName:String = "avatar"
    
    var body: some View {
        Image(imgName).resizable()
        .background(Color.yellow)
        .clipShape(Circle())
        .shadow(radius: 5)
        .contentShape(Circle()) //here
        
   }
}

#Preview {
    ErrorImage()
}

#Preview {
 
    ErrorImage2(imgName: "avatar2")
}


