//
//  ContentView.swift
//  SignIn_doz_03
//
//  Created by Student on 05.12.23.
//

import SwiftUI

struct ContentView: View {
    
    @State var currentIndex = 0
    @State var userTxt:String = ""
    @State var passtxt:String = ""
    
    
    var body: some View {
        VStack {
            if(currentIndex == 0  ){
                Image("avatar")
                Text("Signin")
                
                TextField("user",text:$userTxt).textFieldStyle(.roundedBorder)
                TextField("pass", text:$passtxt).textFieldStyle(.roundedBorder)
                
                Button("login"){
                    checklogin()
                }.font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(minWidth: 10,maxWidth: .infinity)
                    .background(.green)
                
            }
            
            
            
            if(currentIndex == 1 ){  Text("Valid")    }
            
            
            
            if(currentIndex == 2 ){  Text("Invalid")  }
        }
        .padding()
    }
    
    
    func checklogin(){
        if(userTxt == "Ich" && passtxt == "Letmein"){
            currentIndex = 1
        }else{
            currentIndex = 2
        }
    }
    
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
