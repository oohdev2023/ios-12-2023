//
//  InvalidView.swift
//  SignIn_doz_03
//
//  Created by Student on 06.12.23.
//

import SwiftUI

struct InvalidView: View {
    
    var errorCount:Int!
    @Binding var currentIndex:Int
    
    var body: some View {
        Image(systemName: "exclamationmark.triangle")
                            .symbolRenderingMode(.palette)
                            .foregroundStyle(.black, .red)
                            .font(.system(size: 100))
        Text("Das Passwort und deUsername waren nicht valid!")
        Text("Das ist Dein \(errorCount). Versuch!")
        Button("versuch es nochmal bitte"){
            currentIndex = 0
        }
    }
}


