//
//  ContentView.swift
//  SignIn_doz_03
//
//  Created by Student on 05.12.23.
//

import SwiftUI

struct MainView: View {
    
    @State var currentIndex = 0
    @State var userTxt:String = ""
    @State var passtxt:String = ""
    @State var errorCount:Int = 0
    
    
    var body: some View {
        VStack {
            
            //######################------LOGINSCREEN------######################
            if(currentIndex == 0  ){
                Image("avatar")
                Text("Sign in").font(.title).fontWeight(.bold).foregroundColor(Color.green)
                Spacer()
                
                if(errorCount < 3  ){
                
                    TextField("user",text:$userTxt).textFieldStyle(.roundedBorder).autocapitalization(.none)
                    TextField("pass", text:$passtxt).textFieldStyle(.roundedBorder).autocapitalization(.none)

                    Button("login"){
                        checklogin()
                    }.font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(minWidth: 10,maxWidth: .infinity)
                        .background(.green)
                
                }else{
                  Button("setze die Fehlerversuche zurück"){
                       errorCount = 0
                    }
                }
                
                    
                Spacer()
            }
            
            //######################-----VALID LOGIN / STARTSCREEN APP-------######################
            
            if(currentIndex == 1 ){
               
                ListView(user: userTxt)
            }
            
            //######################------INVALID LOGIN SCREEN------######################
            
            if(currentIndex == 2 ){
                InvalidView(errorCount:errorCount,currentIndex: $currentIndex)
            }
        }
        .padding()
    }
    
    
    func checklogin(){
        if(userTxt == "ich" && passtxt == "letmein"){
            currentIndex = 1
        }else{
            errorCount += 1
            currentIndex = 2
        }
    }
    
    
    
}

#Preview {
        MainView()
}

