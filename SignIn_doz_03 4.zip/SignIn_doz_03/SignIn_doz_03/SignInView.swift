//
//  InvalidView.swift
//  SignIn_doz_03
//
//  Created by Student on 06.12.23.
//

import SwiftUI

struct SignInView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ListView()
}
