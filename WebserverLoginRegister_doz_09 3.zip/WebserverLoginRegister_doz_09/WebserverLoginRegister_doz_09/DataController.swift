//
//  DataController.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import Foundation


class DataController:ObservableObject{
    
    @Published var isLogin:Bool = false
     
    var userDataloged:[String:String] = [:]
    
    func sendLoginData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")")
        
        let user:String   = formData["u"] ?? ""
        let pass:String   = formData["p"] ?? ""
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/signin.php?user=\(user)&pass=\(pass)"
        print(urlStr)
        //Wohin
        let url = URL(string: urlStr)!
        //let url = URL(string: "https://www.bild.de/")!
        //Was soll migesendet werden(POST)
        let request = URLRequest(url: url)
        //Wird gesendet
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
            //Beispiel Json:
              //ein object -> Dictionary -> beginnt mit {
            let dict = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [String:String]
            //unendlich viele objecte -> Array mit Dictionaries -> beginnt mit [ ->
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            print(dict["state"] ?? "")
            
            //gehe zurück zum MainThread
            DispatchQueue.main.async {
                self.checkServerOutputSignIn(dict:dict)
            }
            
        }
    
        
        task.resume()
        
        
    }
    
    func checkServerOutputSignIn(dict:[String:String]){
       //Wenn positive Antwort vom Server(state= 3)
            if(dict["state"] == "3"){
                userDataloged = dict
                //zeige startseite
                isLogin = true
                
            }else{
                //ansonsten gebe fehler aus
                //Versucht hier ein AlertFenster in der Main zu öffnen , mit der Ausgabe ... Ein Fehler ist aufgetreten
                //serverOutput = dict
                //isAlert = true
            }
            
            
        }
    
    
    
    
    
    
    
    
    
    
    
    func sendRegisterData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")/ \(formData["e"] ?? "")")
        
        let user:String   = formData["u"] ?? ""
        let pass:String   = formData["p"] ?? ""
        let email:String   = formData["e"] ?? ""
        let urlStr:String = "http://127.0.0.1/ios24/signinsignup/signup.php?user=\(user)&pass=\(pass)&email=\(email)"
        print(urlStr)
        //Wohin
        let url = URL(string: urlStr)!
        //let url = URL(string: "https://www.bild.de/")!
        //Was soll migesendet werden(POST)
        let request = URLRequest(url: url)
        //Wird gesendet
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) {
            (data, response, error) in
            //Daten in Bytes
            print(data ?? Data())
            //Daten in Text
            print(String(decoding: data!, as: UTF8.self))
            
            //Antwort wird verarbeitet
            //Beispiel Json:
              //ein object -> Dictionary -> beginnt mit {
            let dict = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [String:String]
            //unendlich viele objecte -> Array mit Dictionaries -> beginnt mit [ ->
            //let arr = try! JSONSerialization.jsonObject(with: data ?? Data(), options: []) as! [[String:String]]
            print(dict["state"] ?? "")
        }
    
        
        task.resume()
        
        
        
    }
    
    
}
