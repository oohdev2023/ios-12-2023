
import SwiftUI

struct SignUpView: View {
    
    @EnvironmentObject var dc:DataController
    
    
    @Binding var pageID:Int
    
    @State var uservalue:String = ""
    @State var passwordvalue:String = ""
    @State var emailvalue:String = ""
    //boolzum anzeigen und schliessen des alert fensters
    @State private var showingAlert = false
    
    var body: some View {
        
        Text("SIGNUP")
        
        
        
        Form {
            Section {
                TextField("user", text: $uservalue)
            }

            Section {
                TextField("email", text: $emailvalue)
            }
            
            Section {
                TextField("password", text: $passwordvalue)
            }
            
            Button("send") {
                checkForm(u:uservalue,p:passwordvalue,e:emailvalue)
            }
        }
        .padding().alert("Username or Password or Email to short!", isPresented: $showingAlert) {
            Button("OK", role: .cancel) { }
        }.autocapitalization(.none)
            .disableAutocorrection(true)
        
        Button("change to SignIn") {
             pageID = 0
        }
        
        
    }
    
    func checkForm(u:String,p:String,e:String){
        if(u.count < 3  || p.count < 6 || e.count < 6){
            showingAlert = true
        }else{
            //packe Formdaten zusammen und sende sie an Main -> änder eine BindingVar zum Aktualisieren
            var formData:[String:String] = ["u":u,"p":p,"e":e]
            
            dc.sendRegisterData(formData: formData)
            
        }
    }
    
}


