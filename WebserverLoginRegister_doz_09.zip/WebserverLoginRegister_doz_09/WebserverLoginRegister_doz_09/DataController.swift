//
//  DataController.swift
//  WebserverLoginRegister_doz_09
//
//  Created by Student on 09.01.24.
//

import Foundation


class DataController:ObservableObject{
    
    
    func sendLoginData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")")
        
        
        
        
        
        
    }
    
    func sendRegisterData(formData:[String:String]){
        print("sendLoginData:\(formData["u"] ?? "") / \(formData["p"] ?? "")/ \(formData["e"] ?? "")")
    }
    
    
}
