//
//  MyFirstSwiftUI_doz_02App.swift
//  MyFirstSwiftUI-doz-02
//
//  Created by Student on 05.12.23.
//

import SwiftUI

@main
struct MyFirstSwiftUI_doz_02App: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
