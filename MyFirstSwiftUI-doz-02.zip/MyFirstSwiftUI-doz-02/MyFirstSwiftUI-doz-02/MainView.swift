//
//  ContentView.swift
//  MyFirstSwiftUI-doz-02
//
//  Created by Student on 05.12.23.
//

import SwiftUI

struct MainView: View {
    //Einmal beim benutZen der Structur ausgeführt
    var textcontent:String = "Hallo"
    
    //@State -> zur Laufzeit veränderbar -> alle UI-Elemente die von dieser Variabeln betroffen sind werden automatisch aktualisiert
    @State var textcontentdynamic:String = "Du"
    @State var opacity:Double = 1
    
    @State var textinput:String = ""
    
    var body: some View {
        VStack {
            HStack{
                Text(textcontent).padding().opacity(opacity)
                Text(textcontentdynamic).padding()
            }.padding().border(Color.red, width: 1.0)
            
            //#######-IN&OUTPUT TEXT-#####
            Text(textinput).font(.largeTitle).foregroundColor(.red).padding().background(.green)
            Text(textinput).font(.largeTitle).foregroundColor(.red).padding().background(.green)
            
            TextField("...", text: $textinput).border(Color.gray, width: 1.0).padding(10)
            
            //#######-Images-#####
            Image(systemName: "star.fill").resizable().frame(width: 50,height:50).padding()
            
            
           
            //#######-BUTTONS-#####
            //simple Button (Text)
            Button("change Text"){
                textcontentdynamic = "tttt"
            }
            
            //expert Button
            Button{
                opacity = 0
            }label:{
                Text("change opacity").font(.headline)
                                      .foregroundColor(.gray)
                                      .padding()
                                      .frame(minWidth: 10,maxWidth: .infinity)
                                      .background(.orange)
                                      .padding(.trailing,15)
                                      .padding(.leading,15)
            }
            
            Button{
                opacity = 0
            }label:{
                Image(systemName: "star.fill")
                                      .foregroundColor(.gray)
                                      .padding()
                                      .frame(minWidth: 10,maxWidth: 50)
                                      .background(.orange)
                                      .cornerRadius(25)
                                      .shadow(color: .gray, radius: 3, x: 2, y: 2)
                                      .padding(.trailing,15)
                                      .padding(.leading,15)
            }
            
            
            
            
        }.border(Color.red, width: 1.0)
        
    }
    
    
    
}




//NUR FÜR LIVE PREVIEW
struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
