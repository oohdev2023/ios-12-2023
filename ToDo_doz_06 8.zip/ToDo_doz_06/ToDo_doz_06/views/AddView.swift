//
//  AddView.swift
//  Touri_MVC
//
//  Created by Student on 13.12.23.
//

import SwiftUI

//Datenstruktur zur übergabe alle Formadaten über die ContentView an den DataController
struct FormData{
    
    
}



struct AddView: View {
    
    @State var name:String = ""
    
    var body: some View {
        
        
        Form {
            Section(header: Text("title")){
                TextField("title", text:$name)
            }
         
        }
    }
    
    
}

//#Preview {
    //AddView()
//}
