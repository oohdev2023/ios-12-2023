//
//  ContentView.swift
//  ToDoFinal_doz_07
//
//  Created by Student on 18.12.23.
//

import SwiftUI

struct ContentView: View {
 
   @ObservedObject var dc:DataController = DataController()
    
    @State var searchTxt:String = ""
    
    var body: some View {
        VStack {
            ListView(allTodos: dc.getAllTodos(), searchTxt: $searchTxt)
        }.onAppear{
            dc.loadItems()
        }.environmentObject(dc)
    }
}

#Preview {
    ContentView()
}
