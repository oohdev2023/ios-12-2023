//
//  ContentView.swift
//  ToDoFinal_doz_07
//
//  Created by Student on 18.12.23.
//

import SwiftUI

struct ContentView: View {
    
    var dc:DataController = DataController()
    
    
    var body: some View {
        VStack {
           
        }.onAppear{
            dc.loadItems()
        }
    }
}

#Preview {
    ContentView()
}
