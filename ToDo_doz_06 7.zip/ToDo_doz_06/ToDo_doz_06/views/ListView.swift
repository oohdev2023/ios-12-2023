//
//  ListView.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct ListView: View {
    
    var allTodos:[ToDo]!
    
    @Binding var searchTxt:String
    let defaults = UserDefaults.standard
    
    var body: some View {
        TextField("search",text: $searchTxt).textFieldStyle(.roundedBorder).padding().onAppear{
            //Nur wenn Aktualisierung aus OptionView erwünscht
            searchTxt  = defaults.string(forKey: "searchtxt") ?? ""
        }
        List(allTodos,id:\.id){ todo in
            //---- Ein List Item
           ListItem(todo: todo)
        }
    }
}


struct ListItem:View {
    
    var todo:ToDo
    
    var body: some View {
        VStack{
            HStack{
                Rectangle().fill(Color.init(hex: todo.daysLeftColor)!).frame(width: 20,height: 30)
                Text("\(todo.name) / days left:\(todo.daysLeft)")
                Spacer()
                
            }
            Text(todo.categoryString)
            Text(getDateString(d:todo.finishDate))
        }
    }
    
    func getDateString(d:Date)->String{
        
        let formatter3 = DateFormatter()
        formatter3.dateFormat = "dd.MM.yyyy-HH:mm"
        return formatter3.string(from: d)
        
    }
    
    
}




