//
//  OptionVew.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct OptionView: View {
    
    @State var searchTxt:String = ""
    
    @State var toggleBool:[Bool] = [true,true]
    
    let defaults = UserDefaults.standard
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {
            Section(header: Text("search")) {
                TextField("search",text:$searchTxt)
            }
            
            Section(header: Text("categories")) {
                Toggle(isOn: $toggleBool[0]) {
                    Text("private:")
                }
               
                Toggle(isOn: $toggleBool[1]) {
                    Text("office:")
                }
                
                
                
            }
            
            
            
        
            Section {
                
                HStack{
                    Spacer()
                    Button("save") {
                       
                    }.onTapGesture {
                        //speicher die daten in einer interne ablage für jede app einzeln vorhanden
                        saveOption()
                        //schliesse diese View über den aufruf
                        presentationMode.wrappedValue.dismiss()
                    }
                    Spacer()
                    Button("reset") {
                       
                    }.onTapGesture {
                        resetOption()
                    }
                    Spacer()
                    Button("cancel") {
                       
                    }.onTapGesture {
                        presentationMode.wrappedValue.dismiss()
                    }
                    Spacer()
                }
                
            }
        }.onAppear{
            //Bei Anzeigen der OptionView lade alle Sucheinstellungen und zeige diese an
            loadOption()
        }.navigationBarBackButtonHidden(true)
        
    }
    
    
    
    
    func resetOption(){
        
        searchTxt = ""
        toggleBool = [true,true]
        
        saveOption()
    }
    
    func saveOption(){
       
        defaults.set(searchTxt, forKey: "searchtxt")
        defaults.set(toggleBool, forKey: "categoriesBool")
       
    }
    
    func loadOption(){
      
            searchTxt  = defaults.string(forKey: "searchtxt") ?? ""
            toggleBool = (defaults.array(forKey: "categoriesBool") as? [Bool]) ?? [true,true]
           
        
    }
    
    
    
    
}
