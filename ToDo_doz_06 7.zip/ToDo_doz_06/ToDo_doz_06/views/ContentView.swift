//
//  ContentView.swift
//  ToDo_doz_06
//
//  Created by Student on 14.12.23.
//

import SwiftUI

struct ContentView: View {
    
    
    @ObservedObject var dc:DataController = DataController()
    
    @State var searchTxt:String = ""
    
    
    func callFilter(value:String){
        dc.filterDataSearchTxt(searchTxt: value)
        //dc.filterDataSearchTxt(searchTxt: searchTxt)
    }
    
    var body: some View {
        //Text(searchTxt)
        NavigationStack{
            VStack {
                
                ListView(allTodos: dc.getAllTodos(), searchTxt:$searchTxt.onChange(callFilter))
                
                
            }.onAppear{
                //wird immer aufgerufen wenn diese Fenster (ListView) neu angezeigt wird
                dc.filterData()
                
            }.navigationBarTitle(Text("TOURIS FOREVER"),displayMode: .inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        NavigationLink(destination: OptionView(),label:{ Image(systemName: "gear")})
                    }
                    ToolbarItem(placement: .topBarLeading) {
                        NavigationLink(destination: Text("ADDVIEW"),label:{ Image(systemName: "plus.circle")})
                    }
                    
                }   
        }.onAppear{
            //einmal beim start der app
            dc.loadCategories()
            dc.loadTodosFromFile()
        }
    }
}

#Preview {
    ContentView()
}
