//
//  ToDo.swift
//  ToDo_doz_06
//
//  Created by Student on 14.12.23.
//

import Foundation


struct ToDo{
    
    let id:UUID = UUID()
    // die 4 parameter werden  aus der plist eingelesen
    let name:String
    let description:String
    let categoryId:Int
    let finishDate:Date
    //diese 3 parameter werden beim deserialisieren gesetzt(isdone) oder berechnet(daysLeft,daysLeftColor)
    var isDone:Bool = false
    
    var daysLeft:Int = 0
    var daysLeftColor:String  = "#000000"
    //dier parameter wird beim filtern der Daten hinzugefügt bzw. aus CategoriesListe eingefügt
    var categoryString:String = "default"
    
    
}
