//
//  ContentView.swift
//  ToDoFinal_doz_07
//
//  Created by Student on 18.12.23.
//

import SwiftUI

struct ContentView: View {
 
   @ObservedObject var dc:DataController = DataController()
    
    @State var searchTxt:String = ""
    
    var body: some View {
        NavigationStack{
            VStack {
                ListView(allTodos: dc.getAllTodos(), searchTxt: $searchTxt.onChange(dc.filterDataSearchTxt))
                
            }.onAppear{
                dc.loadCategories()
                dc.loadItems()
            }.toolbar {
               
                ToolbarItem(placement: .topBarLeading) {
                    NavigationLink(destination:AddView(allCategories: dc.getAllCategories()),label:{ Image(systemName: "plus.circle")})
                }
                
            }
        }.environmentObject(dc)
    }
}

#Preview {
    ContentView()
}
