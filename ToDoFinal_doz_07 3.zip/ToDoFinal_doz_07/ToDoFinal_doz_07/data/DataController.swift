//
//  DataController.swift
//  ToDo_doz_06
//
//  Created by Student on 14.12.23.
//

import Foundation

class DataController:ObservableObject{
    
    private var allCategories:[Categorie] = []
    
    private var allTodos:[ToDo] = []
    //ausgabe array
    @Published  var allTodosFilter:[ToDo] = []
    
    
    var plistData:NSArray!
    
    
    init(){
        
    }
    //methode
    func loadCategories(){
        let c0:Categorie = Categorie(id: 0, name: "privat", icon: "stop.circle")
        let c1:Categorie = Categorie(id: 1, name: "office", icon: "fireworks")
        let c2:Categorie = Categorie(id: 2, name: "holliday", icon: "party.popper")
        
        allCategories.append(c0)
        allCategories.append(c1)
        allCategories.append(c2)
        
        allCategories = [c0,c1,c2]
        
    }
    
    //=============-LADEN DER PLIST TODOS AUS DEM BUNDEL-==========
    
    func loadTodosFromFile(){
        //Pfad innerhalb des Projektes finden
        let path = Bundle.main.path(forResource: "todo_data", ofType: "plist")
        //einlesen der Datei in ein Array mit Hilfe der Class NSArray (keine vorherige Typisierung nötig)
        plistData = NSArray(contentsOfFile: path!)!
        
        deserializeData()
    }
    
    func deserializeData(){
        //lese jeden Eintrag aus der Plist über das NSArray aus und konvertiere diese in gewünschte Struktur
        for index in 0 ..< plistData.count{
            var t0:ToDo = ToDo(
                name: (plistData.object(at: index) as AnyObject).value(forKey: "name") as! String,
                description: (plistData.object(at: index) as AnyObject).value(forKey: "description") as! String,
                categoryId: (plistData.object(at: index) as AnyObject).value(forKey: "categoryId") as! Int,
                finishDate: (plistData.object(at: index) as AnyObject).value(forKey: "finishdata") as! Date
            )
            
            t0.isDone = (plistData.object(at: index) as AnyObject).value(forKey: "isdone") as! Bool
            t0.daysLeft = Calendar(identifier: .gregorian).numberOfDaysBetween(Date(), and: t0.finishDate)
            t0.daysLeftColor = getColorOfDaysBetween(daysLeft:t0.daysLeft)
            
            allTodos.append(t0)
            print(allTodos)
            saveItems()
        }
        
        filterData()
        
    }
    
    //===================-LADEN DER PLIST TODOS AUS DEM DOKUMENTENORDNER DER APP-===========================
    
    
    func loadItems() {
        
         // Pfad zur Plist im Dokumentenordner
           let fileURL = getDocumentsDirectory().appendingPathComponent("items.plist")
       //Versucht die Datei zu öffnen und einzulesen
       //var data =  (try? Data(contentsOf: fileURL))!
       //print(String(data: data, encoding: .utf8))
        if let data = try? Data(contentsOf: fileURL) {
               let decoder = PropertyListDecoder()
               if let loadedItems = try? decoder.decode([ToDo].self, from: data) {
                   self.allTodos = loadedItems
                   print(allTodos)
                  
               }
               filterData()
           }else{
               loadTodosFromFile()
           }
        
       }
    
    
    //===================-SPEICHERN DER PLIST TODOS IN DEN DOKUMENTENORDNER DER APP-===========================
    func saveItems() {
        let fileURL = getDocumentsDirectory().appendingPathComponent("items.plist")
        let encoder = PropertyListEncoder()
        encoder.outputFormat = .xml
        
        if let data = try? encoder.encode(allTodos) {
            try? data.write(to: fileURL)
        }
    }
    
    
    //===================-Gibt den Pfad zum DokumentenOrdner der App zurück-===========================
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        print(paths)
        return paths[0]
    }
    
    
    //==============-Sortierfunktionen nach Datum-=====================================
    func sortDateDes(){
        allTodosFilter = allTodosFilter.sorted { $0.finishDate > $1.finishDate }
    }
    
    func sortDateAsc(){
        allTodosFilter = allTodosFilter.sorted { $0.finishDate < $1.finishDate }
    }
    
    //===================-Fügt einen Eintrag hinzu und ruft dann das Speichern auf-===========================
    func addTodo(formData:FormData){
        //erzeugt aus den mitgelieferten Formulatdaten ein Onject der gewünschte Struktur
        var todo:ToDo =
        ToDo(name: formData.name,
             description: formData.description,
             categoryId: formData.selectedCat,
             finishDate: formData.finishDate)
        //....
        todo.daysLeft = Calendar(identifier: .gregorian).numberOfDaysBetween(Date(), and: todo.finishDate)
        todo.daysLeftColor = getColorOfDaysBetween(daysLeft:todo.daysLeft)
        
        //hänge dieses erzeugte Object an originale liste aller items
        allTodos.append(todo)
        
        saveItems()
       
        filterData()
    }
    
    
    //====-Löscht einen Eintrag in Abhängigkeit der UUID, die jedem Eintrag automatisch vergeben wird
    
    
    func deletTodo(index:Int){
        
        allTodos.remove(at: index)
        filterData()
        
    }
    
    
    
    func deletTodo(id:UUID){
        
        var index:Int = 0
        //suche im originalen array den eintrag mit der pasenden id und speicher den index diese elementes zwischen
        for i in 0 ..< allTodos.count{
            
            if(allTodos[i].id == id){
                index = i
                print( allTodos[i].id)
                print( id)
               
            }
        }
        
        //nach der schleife lösche das element an dem index
        allTodos.remove(at: index)
        saveItems()
        
        
        filterData()
        
    }
    
    
    func filterDataSearchTxt(searchTxt:String){
        //speicher den Wert für die OptionView ab. wenn gewünscht
        defaults.set(searchTxt, forKey: "searchtxt")
        
        allTodosFilter = []
        if searchTxt == "" {
            //wenn kein suchtext vorhanden
            for todo in allTodos{
                //füge alle Daten hinzu (Kategorien weggelassen)
                if( toggleBool[todo.categoryId] ){
                    var tmp:ToDo = todo
                    tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                    allTodosFilter.append(tmp)
                }
            }
            
        }else{
            for todo in allTodos{
                if todo.name.lowercased().contains(searchTxt.lowercased()) || todo.description.lowercased().contains(searchTxt.lowercased()){
                    if( toggleBool[todo.categoryId] ){
                        //füge alle Daten mit SuchStringMatch hinzu
                        var tmp:ToDo = todo
                        tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                        allTodosFilter.append(tmp)
                    }
                }
            }
        }
        
        
        
    }
    
    
    
    //=======================================================
    
    
    func getColorOfDaysBetween(daysLeft:Int)->String{
        
        switch daysLeft {
        case ...1:
            return "#ff0000"

        case 2...3:
            return "#ffff00"

        case 4...:
            return "#00ff00"

        default:
            return "#ffffff"
        }
    }
    
   
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    func filterData(){

        allTodosFilter = []
        
        //lade die gespeicherten Werte aus der OptionView
        loadOption()
        
        if searchTxt == "" {
            //wenn kein suchtext vorhanden
            for todo in allTodos{
                //füge alle Daten hinzu (Kategorien weggelassen)
                if( toggleBool[todo.categoryId] ){
                    var tmp:ToDo = todo
                    tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                    allTodosFilter.append(tmp)
                }
            }
            
        }else{
            for todo in allTodos{
                if todo.name.lowercased().contains(searchTxt.lowercased()) || todo.description.lowercased().contains(searchTxt.lowercased()){
                    //Die Id der Kategorie ist die Stelle im Array der Toggles([true,true])
                    if( toggleBool[todo.categoryId] ){
                        //füge alle Daten mit SuchStringMatch hinzu
                        var tmp:ToDo = todo
                        tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                        allTodosFilter.append(tmp)
                    }
                    
                }
            }
        }
        sortDateDes()
    }
    
   
    
    
    
    
    let defaults = UserDefaults.standard
    var searchTxt:String = ""
    var toggleBool:[Bool] = [true,true]
    func loadOption(){
      searchTxt  = defaults.string(forKey: "searchtxt") ?? ""
      toggleBool = (defaults.array(forKey: "categoriesBool") as? [Bool]) ?? [true,true]
    }
    
    
    
    func getCategoryStringFromId(id:Int)->String{
        var output:String = ""
        
        for cat in allCategories{
            if(cat.id == id){
                output = cat.name
            }
        }
        
        return output
    }
    
    
    
    //=======================-Zugriffs Methoden-==================================
    func getAllTodos()->[ToDo]{ return allTodosFilter }
    func getAllTodosCount()->Int{ return allTodosFilter.count }
    func getTodoAt(index:Int)->ToDo{
        var tmpIndex:Int = index
        if(tmpIndex < 0){ tmpIndex = 0}
        if(tmpIndex >= getAllTodosCount()){ tmpIndex = getAllTodosCount()-1}
        return allTodosFilter[tmpIndex]
    }
    //------------------------------------------------------------------------------

    func getAllCategories()->[Categorie]{ return allCategories }
    func getAllCategoriesCount()->Int{ return allCategories.count }
    func getCategoryAt(index:Int)->Categorie{
        var tmpIndex:Int = index
        if(tmpIndex < 0){ tmpIndex = 0}
        if(tmpIndex >= getAllCategoriesCount()){ tmpIndex = getAllCategoriesCount()-1}
        return allCategories[tmpIndex]
    }
    
    //===============================================================================
}
