//
//  DataController.swift
//  ToDo_doz_06
//
//  Created by Student on 14.12.23.
//

import Foundation

class DataController:ObservableObject{
    
    private var allCategories:[Categorie] = []
    
    private var allTodos:[ToDo] = []
    //ausgabe array
    @Published private var allTodosFilter:[ToDo] = []
   
    init(){
        
    }
    //methode
     func loadCategories(){
        let c0:Categorie = Categorie(id: 0, name: "privat", icon: "stop.circle")
        let c1:Categorie = Categorie(id: 1, name: "office", icon: "fireworks")
        let c2:Categorie = Categorie(id: 2, name: "holliday", icon: "party.popper")
        
        allCategories.append(c0)
        allCategories.append(c1)
        allCategories.append(c2)
    
        allCategories = [c0,c1,c2]
        
    }
    
    var plistData:NSArray!
    func loadTodosFromFile(){
        //Pfad innerhalb des Projektes finden
        let path = Bundle.main.path(forResource: "todo_data", ofType: "plist")
        //einlesen der Datei in ein Array mit Hilfe der Class NSArray (keine vorherige Typisierung nötig)
        plistData = NSArray(contentsOfFile: path!)!
        
        deserializeData()
    }
    
    func deserializeData(){
        //lese jeden Eintrag aus der Plist über das NSArray aus und konvertiere diese in gewünschte Struktur
        for index in 0 ..< plistData.count{
            /*print( (plistData.object(at: index) as AnyObject).value(forKey: "name") as! String )
            print( (plistData.object(at: index) as AnyObject).value(forKey: "description") as! String )
            print( (plistData.object(at: index) as AnyObject).value(forKey: "categoryId") as! Int )
            print( (plistData.object(at: index) as AnyObject).value(forKey: "finishdata") as! Date )
            print( (plistData.object(at: index) as AnyObject).value(forKey: "isdone") as! Bool )*/
            
            var t0:ToDo = ToDo(
                name: (plistData.object(at: index) as AnyObject).value(forKey: "name") as! String,
                description: (plistData.object(at: index) as AnyObject).value(forKey: "description") as! String,
                categoryId: (plistData.object(at: index) as AnyObject).value(forKey: "categoryId") as! Int,
                finishDate: (plistData.object(at: index) as AnyObject).value(forKey: "finishdata") as! Date
            )
            
                t0.isDone = (plistData.object(at: index) as AnyObject).value(forKey: "isdone") as! Bool
                t0.daysLeft = Calendar(identifier: .gregorian).numberOfDaysBetween(Date(), and: t0.finishDate)
                t0.daysLeftColor = getColorOfDaysBetween(daysLeft:t0.daysLeft)
            
            allTodos.append(t0)
            
        }
        
        filterData()
        
    }
    
    func addTodo(formData:FormData){
        //erzeugt aus den mitgelieferten Formulatdaten ein Onject der gewünschte Struktur
        var todo:ToDo =
        ToDo(name: formData.name,
             description: formData.description,
             categoryId: formData.selectedCat,
             finishDate: formData.finishDate)
        //....
        todo.daysLeft = Calendar(identifier: .gregorian).numberOfDaysBetween(Date(), and: todo.finishDate)
        todo.daysLeftColor = getColorOfDaysBetween(daysLeft:todo.daysLeft)
        
        //hänge dieses erzeugte Object an originale liste aller items
        allTodos.append(todo)
        //savaData()
        //loadData()
        filterData()
    }
    
    func getColorOfDaysBetween(daysLeft:Int)->String{
        
        switch daysLeft {
        case ...1:
            return "#ff0000"

        case 2...3:
            return "#ffff00"

        case 4...:
            return "#00ff00"

        default:
            return "#ffffff"
        }
    }
    
    
    
     func loadTodos(){
        
        let t0:ToDo = ToDo(
            name: "Essen bei Michi",
            description: "Lamm hat er versprochen",
            categoryId: 0,
            finishDate: Date()
        )
        
        let t1:ToDo = ToDo(
            name: "Welt Übergabe",
            description: "Giothup Repro übergeben",
            categoryId: 1,
            finishDate: Date()
        )
        
        let t2:ToDo = ToDo(
            name: "CimData VR Christmas",
            description: "Weihnachtsfeier am Montag über Zoom",
            categoryId: 1,
            finishDate: Date()
        )
        
        allTodos = [t0,t1,t2]
        
        filterData()
        
    }
    
    
    func filterDataSearchTxt(searchTxt:String){
        //speicher den Wert für die OptionView ab. wenn gewünscht
        defaults.set(searchTxt, forKey: "searchtxt")
        
        allTodosFilter = []
        if searchTxt == "" {
            //wenn kein suchtext vorhanden
            for todo in allTodos{
                //füge alle Daten hinzu (Kategorien weggelassen)
                if( toggleBool[todo.categoryId] ){
                    var tmp:ToDo = todo
                    tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                    allTodosFilter.append(tmp)
                }
            }
            
        }else{
            for todo in allTodos{
                if todo.name.lowercased().contains(searchTxt.lowercased()) || todo.description.lowercased().contains(searchTxt.lowercased()){
                    if( toggleBool[todo.categoryId] ){
                        //füge alle Daten mit SuchStringMatch hinzu
                        var tmp:ToDo = todo
                        tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                        allTodosFilter.append(tmp)
                    }
                }
            }
        }
        
        
        
    }
    
    
    
    
    
    
    func filterData(){

        allTodosFilter = []
        
        //lade die gespeicherten Werte aus der OptionView
        loadOption()
        
        if searchTxt == "" {
            //wenn kein suchtext vorhanden
            for todo in allTodos{
                //füge alle Daten hinzu (Kategorien weggelassen)
                if( toggleBool[todo.categoryId] ){
                    var tmp:ToDo = todo
                    tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                    allTodosFilter.append(tmp)
                }
            }
            
        }else{
            for todo in allTodos{
                if todo.name.lowercased().contains(searchTxt.lowercased()) || todo.description.lowercased().contains(searchTxt.lowercased()){
                    //Die Id der Kategorie ist die Stelle im Array der Toggles([true,true])
                    if( toggleBool[todo.categoryId] ){
                        //füge alle Daten mit SuchStringMatch hinzu
                        var tmp:ToDo = todo
                        tmp.categoryString = getCategoryStringFromId(id:todo.categoryId)
                        allTodosFilter.append(tmp)
                    }
                    
                }
            }
        }
        
    }
    
    let defaults = UserDefaults.standard
    var searchTxt:String = ""
    var toggleBool:[Bool] = [true,true]
    func loadOption(){
      searchTxt  = defaults.string(forKey: "searchtxt") ?? ""
      toggleBool = (defaults.array(forKey: "categoriesBool") as? [Bool]) ?? [true,true]
    }
    
    
    
    func getCategoryStringFromId(id:Int)->String{
        var output:String = ""
        
        for cat in allCategories{
            if(cat.id == id){
                output = cat.name
            }
        }
        
        return output
    }
    
    
    
    //=======================-Zugriffs Methoden-==================================
    func getAllTodos()->[ToDo]{ return allTodosFilter }
    func getAllTodosCount()->Int{ return allTodosFilter.count }
    func getTodoAt(index:Int)->ToDo{
        var tmpIndex:Int = index
        if(tmpIndex < 0){ tmpIndex = 0}
        if(tmpIndex >= getAllTodosCount()){ tmpIndex = getAllTodosCount()-1}
        return allTodosFilter[tmpIndex]
    }
    //------------------------------------------------------------------------------

    func getAllCategories()->[Categorie]{ return allCategories }
    func getAllCategoriesCount()->Int{ return allCategories.count }
    func getCategoryAt(index:Int)->Categorie{
        var tmpIndex:Int = index
        if(tmpIndex < 0){ tmpIndex = 0}
        if(tmpIndex >= getAllCategoriesCount()){ tmpIndex = getAllCategoriesCount()-1}
        return allCategories[tmpIndex]
    }
    
    //===============================================================================
}
