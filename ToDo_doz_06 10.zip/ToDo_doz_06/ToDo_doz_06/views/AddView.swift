//
//  AddView.swift
//  Touri_MVC
//
//  Created by Student on 13.12.23.
//

import SwiftUI

//Datenstruktur zur übergabe alle Formadaten über die ContentView an den DataController
struct FormData{
    
    let name:String
    let description:String
    let selectedCat:Int
    let finishDate:Date
    
}



struct AddView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @State var name:String = "new ToDo"
    @State var description:String = "Das alles und noch viel mehr"
    @State var selectedCat:Int = 0
    @State var finishDate:Date = Date()
    
    var allCategories:[Categorie]
    
    @Binding var formData:FormData
    
    var body: some View {
        
        
        Form {
            Section(header: Text("title")){
                TextField("title", text:$name)
            }
            
            Section(header: Text("description")){
                TextField("title", text:$description)
            }
            
            Section(header: Text("category")){
                Picker("Please choose a category", selection: $selectedCat) {
                               ForEach(allCategories, id: \.id) {
                                   //Anzeige:Text("\($0.name)")
                                   //Fespeichert über selection Binding:.tag($0.id)
                                   Text("\($0.name)").tag($0.id)
                               }
                           }
                           //Text("You selected: \(selectedCat)")
            }
            
            
            Section(header: Text("finish date")){
                DatePicker("Select a date",selection: $finishDate, in: Date.now..., displayedComponents: [.date,.hourAndMinute]).labelsHidden()
                DatePicker("Select a date",selection: $finishDate, in: Date.now..., displayedComponents: .date)
                
                DatePicker(selection: $finishDate, in: Date.now..., displayedComponents: .date) {
                            Text("Select a date")
                }
                        Text("Date\(finishDate)")
            
            }
            
            Section {
                
                HStack{
                    Spacer()
                    Button("save") {
                       
                    }.onTapGesture {
                        //speicher die daten in einer interne ablage für jede app einzeln vorhanden
                        sendData()
                        //schliesse diese View über den aufruf
                        presentationMode.wrappedValue.dismiss()
                    }
                    Spacer()
                   
                    Spacer()
                    Button("cancel") {
                       
                    }.onTapGesture {
                        presentationMode.wrappedValue.dismiss()
                    }
                    Spacer()
                }
                
            }
         
        }
    }
    
    func sendData(){
        //auf savebutton wird ein paket gepackt (struct FormData wird erzeugt)
        formData = FormData(
            name: name,
            description: description,
            selectedCat: selectedCat,
            finishDate: finishDate
        )
    }
    
    
}

//#Preview {
    //AddView()
//}
