//
//  ToDo_doz_06App.swift
//  ToDo_doz_06
//
//  Created by Student on 14.12.23.
//

import SwiftUI

@main
struct ToDo_doz_06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
