//
//  OptionVew.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct OptionView: View {
    
    
    @State var toggleBool:[Bool] = [true,true,true]
    
    let defaults = UserDefaults.standard
    
    var allCategories:[Categorie]
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        List {
            
            Section(header: Text("categories")) {
                ForEach(allCategories, id: \.id) { cat in //---- Ein List Item
                    
                    
                    Toggle(isOn: $toggleBool[cat.id]) {
                        Text(cat.name)
                    }.onTapGesture {
                        setToggle()
                    }
                    
                    
                }
                
                
            }.onAppear{
                getToggle()
            }
            
            
        }
       
        
    }
    
    func getToggle(){
        toggleBool = (defaults.array(forKey: "categoriesBool") as? [Bool]) ?? [true,true,true]
    }
    
    
    func setToggle(){
        defaults.set(toggleBool, forKey: "categoriesBool")
    }
    
}
