//
//  modifier.swift
//  SignIn_doz_03
//
//  Created by Student on 06.12.23.
//

import Foundation
import SwiftUI

struct MyTitle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.largeTitle)
            .foregroundStyle(.white)
            .padding()
            .background(.blue)
            .clipShape(.rect(cornerRadius: 10))
    }
}


extension Text {
    func myTitle() -> some View {
        modifier(MyTitle())
    }
}




struct MyRoundImage: ViewModifier {
    func body(content: Content) -> some View {
        content
            .background(Color.yellow)
.clipShape(Circle())
.shadow(radius: 5)
.contentShape(Circle()) //here
    }
}


extension Image {
    func roundImage() -> some View {
        modifier(MyRoundImage())
    }
}
