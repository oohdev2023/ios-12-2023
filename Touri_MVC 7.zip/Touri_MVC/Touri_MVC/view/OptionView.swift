//
//  OptionVew.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct OptionVew: View {
    var body: some View {
        Text("OPTON")
    }
}

#Preview {
    OptionVew()
}
