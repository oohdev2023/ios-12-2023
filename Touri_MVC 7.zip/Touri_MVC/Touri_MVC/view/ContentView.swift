//
//  ContentView.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import SwiftUI

struct ContentView: View {
    
    //Erzeuge eine Instanz/Objekt der Class und fülle dadurch automatisch die Daten in die Liste
    private var dc:DataController = DataController()
    
    var body: some View {
        
            NavigationStack{
                VStack {
                 ListView(allData: dc.getAllData())
                }.navigationBarTitle(Text("TOURIS FOREVER"),displayMode: .inline) 
                    .toolbar {
                       
                        ToolbarItem(placement: .bottomBar) {
                            NavigationLink(destination: ListView(allData: dc.getAllData()), label:{ Image(systemName: "list.bullet")})                            
                        }
                        ToolbarItem(placement: .bottomBar) {
                            NavigationLink("Map", destination: MapView())
                        }
                        ToolbarItem(placement: .bottomBar) {
                            NavigationLink("Grid", destination: GridView())
                        }
                      
                }
           }
        .padding()
    }
}







#Preview {
    ContentView()
}
