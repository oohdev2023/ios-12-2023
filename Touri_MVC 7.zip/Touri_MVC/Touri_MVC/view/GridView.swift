//
//  GridView.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct GridView: View {
    var body: some View {
        Text("Grid")
    }
}

#Preview {
    GridView()
}
