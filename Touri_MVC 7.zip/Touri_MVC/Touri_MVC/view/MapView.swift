//
//  MapView.swift
//  Touri_MVC
//
//  Created by Student on 11.12.23.
//

import SwiftUI

struct MapView: View {
    var body: some View {
        Text("Map")
    }
}

#Preview {
    MapView()
}
