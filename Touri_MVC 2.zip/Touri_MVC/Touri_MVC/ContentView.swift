//
//  ContentView.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import SwiftUI

struct ContentView: View {
    
    //Erzeuge eine Instanz/Objekt der Class und fülle dadurch automatisch die Daten in die Liste
    var dc:DataController = DataController()
    
    var body: some View {
        VStack {
            //Über die Instanzvariable kann jetzt immer auf die Daten(Liste) zugegriffen werden
            List{
                Text(dc.allData[0].title)
                Text(dc.allData[1].title)
                Text(dc.allData[2].title)
            }
//List(Array mit Objekten, Eigenschaft des Objektes welche eindeutig ist)
            List(dc.allData,id:\.id){ place in
                //---- Ein List Item
                HStack{
                    Image(place.img).resizable().frame(width: 50,height:50)
                    Text(place.title)
                }
                //----
                
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
