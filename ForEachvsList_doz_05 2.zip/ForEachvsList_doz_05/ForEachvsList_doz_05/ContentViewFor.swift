//
//  ContentView.swift
//  ForEachvsList_doz_05
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ContentViewFor: View {
    
    var aCat:[String] = ["club","sight","food"]
    
    
    
    var body: some View {
        VStack {
            HStack{
                ForEach( aCat ,id:  \.self) { _ in
                    Text("|")
                }
            }
            Divider()
            ForEach( aCat ,id:  \.self) { item in
                Text(item)
            }
            Divider()
            ForEach( 1 ..< 5 ) { i in
                Text("lol")
            }
            Divider()
            ForEach( 1 ... 5, id: \.self) { i in
                Text("lol\(i)")
            }
            Divider()
            ForEach( 1...5 , id: \.self) {
                Text("lol\($0)")
            }
        }
        .padding()
    }
}

#Preview {
    ContentViewFor()
}
