//
//  ContentView.swift
//  ForEachvsList_doz_05
//
//  Created by Student on 07.12.23.
//

import SwiftUI

struct ContentViewList: View {
    
    var aCat:[String] = ["club","sight","food"]
    
    
    
    var body: some View {
        VStack {
            //statische Liste
            List{
                Text("1")
                Text("2")
                Text("3")
            }
            List{
                ForEach( 1 ..< 50 ) { i in
                    Text("Text \(i)")
                }
            }
            
            
            List(aCat,id:\.self){ item in
                HStack{
                    Image(item).resizable().frame(width:50,height:50)
                    Text(item)
                }
            }
            
            
            NavigationStack{
                List(aCat,id:\.self){ item in
                    NavigationLink(destination:Text(item)){
                        HStack{
                            Image(item).resizable().frame(width:50,height:50)
                            Text(item)
                        }
                    }
                }
            }
            
            
        }
        .padding()
    }
}

#Preview {
    ContentViewList()
}
