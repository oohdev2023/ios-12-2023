//
//  Place.swift
//  Touri_MVC
//
//  Created by Student on 08.12.23.
//

import Foundation
//Definition eines Datensatzes

//Codable -> Serializieren von unbekannten DatenTypen

//Identifiable
//Hashable

struct Place{
    
    let id:UUID = UUID()
    //let id:Int
    let title:String
    let description:String
    let img:String
    let categorie:String
    let lat:Double
    let lon:Double
    let ranking:Int
    //var title:String = "Koti"
    //var title:String
}
